from __future__ import annotations

import base64
import gzip
import re
import shutil
from pathlib import Path

RELEASE = "20260901stable2"
ROOT = Path(".")
SITE = ROOT / "_site"


def replace_view(html: str, view: str, label: str, message: str, aliases: tuple[str, ...] = ()) -> str:
    names = (view, *aliases)
    name_pattern = "|".join(re.escape(name) for name in names)
    pattern = rf"\s*(?:<!--\s*{re.escape(label)}S?\s*-->\s*)?<section class=\"view\" data-view=\"(?:{name_pattern})\">.*?</section>\s*"
    replacement = (
        f"\n<!-- {label} -->\n"
        f"<section class=\"view\" data-view=\"{view}\">"
        f"<div style=\"padding:28px;border:1px solid #dce6de;border-radius:14px;background:#fff;color:#034c1f;font:600 14px Arial,sans-serif\">"
        f"{message}</div></section>\n"
    )
    html, count = re.subn(pattern, replacement, html, count=1, flags=re.I | re.S)
    if count != 1:
        raise RuntimeError(f"Expected one {view} section (aliases: {aliases}); replaced {count}.")
    return html


def route_values(html: str, attribute: str) -> list[str]:
    return [value.strip().lower() for value in re.findall(rf'{re.escape(attribute)}=["\']([^"\']+)["\']', html, flags=re.I)]


def validate_navigation_contract(html: str) -> None:
    nav_routes = route_values(html, "data-view")
    section_routes = [
        value.strip().lower()
        for value in re.findall(r'<section\b[^>]*\bclass=["\'][^"\']*\bview\b[^"\']*["\'][^>]*\bdata-view=["\']([^"\']+)["\']', html, flags=re.I)
    ]
    button_routes = [
        value.strip().lower()
        for value in re.findall(r'<button\b[^>]*\bclass=["\'][^"\']*\bnav-item\b[^"\']*["\'][^>]*\bdata-view=["\']([^"\']+)["\']', html, flags=re.I)
    ]
    section_set = set(section_routes)
    unresolved = sorted(set(button_routes) - section_set)
    duplicate_sections = sorted(route for route in section_set if section_routes.count(route) > 1)
    if unresolved:
        raise RuntimeError(f"Navigation routes without matching views: {unresolved}")
    if duplicate_sections:
        raise RuntimeError(f"Duplicate view routes detected: {duplicate_sections}")
    if "survey" not in button_routes or "survey" not in section_set:
        raise RuntimeError("Survey Analytics must use the canonical 'survey' route in navigation and content.")
    if "surveys" in nav_routes:
        raise RuntimeError("Legacy Survey Analytics route alias survived materialization.")


def build() -> None:
    chunks = [ROOT / f"chunks/chunk-{i:02d}.txt" for i in range(7)]
    missing = [str(p) for p in chunks if not p.exists()]
    if missing:
        raise RuntimeError(f"Missing frontend chunks: {missing}")

    encoded = "".join(p.read_text(encoding="utf-8").strip() for p in chunks)
    html = gzip.decompress(base64.b64decode(encoded)).decode("utf-8")

    html = html.replace('id="username" type="email" value="quest@medtech.com"', 'id="username" type="email" value=""')
    html = html.replace('id="password" type="password" value="evalueserve"', 'id="password" type="password" value=""')

    html = re.sub(r'\s*<button class="nav-item" data-view="landscape">.*?</button>\s*', '\n', html, count=1, flags=re.I | re.S)
    html = re.sub(r'\s*<!--\s*LANDSCAPE\s*-->\s*<section class="view" data-view="landscape">.*?</section>\s*', '\n', html, count=1, flags=re.I | re.S)
    html = re.sub(r'\s*<(?P<tag>button|a)\b[^>]*\bdata-view-jump=["\']landscape["\'][^>]*>.*?</(?P=tag)>\s*', '\n', html, flags=re.I | re.S)
    html = re.sub(r'\sdata-view-jump=["\']landscape["\']', '', html, flags=re.I)
    html = re.sub(r",\s*landscape\s*:\s*['\"]Competitive Landscape['\"]", "", html, count=1, flags=re.I)
    html = re.sub(r"\s*chart\('positioningBubble'.*?\);\s*", "\n", html, count=1, flags=re.S)
    html = re.sub(r"\s*chart\('capabilityRadar'.*?\);\s*", "\n", html, count=1, flags=re.S)

    if re.search(r'>\s*Competitive Landscape\s*<|data-view=["\']landscape["\']|data-view-jump=["\']landscape["\']', html, flags=re.I):
        raise RuntimeError("Competitive Landscape markup or navigation residue survived materialization.")

    buttons = re.findall(r'<button\s+class="nav-item"[^>]*>.*?</button>', html, flags=re.I | re.S)
    tracker = next((b for b in buttons if re.search(r'>\s*Project Tracker\s*<', b, flags=re.I)), None)
    evidence = next((b for b in buttons if re.search(r'>\s*Evidence Library\s*<', b, flags=re.I)), None)
    survey_button = next((b for b in buttons if re.search(r'>\s*Survey Analytics\s*<', b, flags=re.I)), None)
    if not tracker or not evidence or not survey_button:
        raise RuntimeError("Project Tracker, Evidence Library, or Survey Analytics navigation item is missing.")
    html = html.replace(evidence, "", 1)
    html = html.replace(tracker, tracker + "\n" + evidence, 1)
    if html.find(tracker) < 0 or html.find(evidence) < html.find(tracker):
        raise RuntimeError("Evidence Library is not positioned after Project Tracker.")

    normalized_survey_button = re.sub(r'data-view="surveys?"', 'data-view="survey"', survey_button, count=1, flags=re.I)
    html = html.replace(survey_button, normalized_survey_button, 1)

    html = replace_view(html, "pmr", "PMR", "Loading PMR repository and analysis dashboard...")
    html = replace_view(html, "experts", "EXPERTS", "Loading Voice of Experts persona analysis...")
    html = replace_view(html, "survey", "SURVEY", "Loading multi-project Survey Analytics...", aliases=("surveys",))

    html = re.sub(
        r'<script\b[^>]*\bsrc=["\']https://cdn\.jsdelivr\.net/npm/chart\.js[^"\']*["\'][^>]*>\s*</script>',
        f'<script src="integrations/chart-lite.js?v={RELEASE}"></script>',
        html,
        flags=re.I,
    )
    html = re.sub(
        r'<script\b[^>]*\bsrc=["\'](?:\.\/)?integrations/[^"\']+["\'][^>]*>\s*</script>',
        lambda m: m.group(0) if "chart-lite.js" in m.group(0) else "",
        html,
        flags=re.I,
    )

    scripts = "".join(
        [
            f'<script src="integrations/frontend-critical-nav-survey.js?v={RELEASE}"></script>',
            f'<script src="integrations/survey-analytics-dashboard-final.js?v={RELEASE}"></script>',
            f'<script src="integrations/survey-analytics-failsafe.js?v={RELEASE}"></script>',
            f'<script src="integrations/chart-alignment-system.js?v={RELEASE}"></script>',
            f'<script src="integrations/frontend-quality-guard.js?v={RELEASE}"></script>',
            f'<script src="integrations/platform-runtime-stability.js?v={RELEASE}"></script>',
            f'<script src="integrations/optimized-loader.js?v={RELEASE}"></script>',
            f'<script src="integrations/quest-enterprise-insights-override.js?v={RELEASE}"></script>',
            f'<script src="integrations/competitive-intelligence-live-refresh/loader.js?v={RELEASE}"></script>',
            f'<script src="integrations/alerts-chatgpt-summaries.js?v={RELEASE}"></script>',
        ]
    )
    if "</body>" not in html:
        raise RuntimeError("Materialized shell has no closing body tag.")
    html = html.replace("</body>", scripts + "</body>", 1)

    required = [
        'data-view="survey"',
        "Loading multi-project Survey Analytics",
        "frontend-critical-nav-survey.js",
        "survey-analytics-dashboard-final.js",
        "survey-analytics-failsafe.js",
        "chart-alignment-system.js",
        "frontend-quality-guard.js",
        "platform-runtime-stability.js",
        "optimized-loader.js",
        "quest-enterprise-insights-override.js",
        "competitive-intelligence-live-refresh/loader.js",
        "alerts-chatgpt-summaries.js",
    ]
    missing_tokens = [token for token in required if token not in html]
    if missing_tokens:
        raise RuntimeError(f"Materialized shell missing required tokens: {missing_tokens}")

    validate_navigation_contract(html)

    if SITE.exists():
        shutil.rmtree(SITE)
    SITE.mkdir(parents=True)
    (SITE / "index.html").write_text(html, encoding="utf-8")

    for name in ("integrations", "data"):
        shutil.copytree(ROOT / name, SITE / name)
    if (ROOT / "assets").is_dir():
        shutil.copytree(ROOT / "assets", SITE / "assets")
    (SITE / ".nojekyll").touch()

    print(f"Materialized Quest Pages release {RELEASE}: {len(html):,} HTML characters")


if __name__ == "__main__":
    build()
