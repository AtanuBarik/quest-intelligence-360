/* Integration QA: NODE_PATH=/tmp/quest-qa/node_modules node tests/maci-workspace.test.cjs
   Install jsdom@26 in that temporary directory. Persona browser coverage is separate. */
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{JSDOM,VirtualConsole}=require('jsdom');
const root=path.resolve(__dirname,'..'),html=fs.readFileSync(path.join(root,'_site/index.html'),'utf8');
const modules=['workspace-experience','maci-evidence-model','team-workspaces','role-access-governance','maci-research-center','persona-intelligence','frontend-critical-nav-survey','platform-runtime-stability','pmr-repository-dashboard-final','voice-experts-dashboard-final','survey-analytics-dashboard-final','competitor-profiles-final'];
const pause=n=>new Promise(r=>setTimeout(r,n));
async function app(team,role,local=null){
 const errors=[],logs=new VirtualConsole();logs.on('jsdomError',e=>{if(!/navigation|canvas/.test(e.message))errors.push(e.message);});logs.on('error',(...e)=>errors.push(e.join(' ')));
 const dom=new JSDOM(html,{url:'https://atanubarik.github.io/quest-intelligence-360/',runScripts:'outside-only',pretendToBeVisual:true,virtualConsole:logs}),w=dom.window;
 w.requestAnimationFrame=cb=>w.setTimeout(()=>cb(Date.now()),0);w.cancelAnimationFrame=id=>w.clearTimeout(id);w.scrollTo=()=>{};w.HTMLElement.prototype.scrollIntoView=()=>{};w.matchMedia=()=>({matches:false,addEventListener(){},removeEventListener(){}});w.ResizeObserver=class{observe(){}disconnect(){}};w.CSS={escape:s=>s};
 w.Chart=class{static register(){}static defaults={};static getChart(){return null;}constructor(){this.data={};}destroy(){}resize(){}update(){}};
 w.fetch=async url=>{const u=new URL(String(url),w.location.href),relative=u.pathname.replace(/^\/quest-intelligence-360\//,'');try{const content=fs.readFileSync(path.join(root,relative),'utf8');return{ok:true,status:200,json:async()=>JSON.parse(content),text:async()=>content};}catch{return{ok:false,status:404,json:async()=>({}),text:async()=>''};}};
 const downloads=[];w.URL.createObjectURL=blob=>{downloads.push(blob);return'blob:test';};w.URL.revokeObjectURL=()=>{};w.HTMLAnchorElement.prototype.click=()=>{};
 w.sessionStorage.setItem('quest360-session-v2',JSON.stringify({team,role,maxRole:role,email:'qa@example.org',stage:'app',displayName:'Quest team'}));if(local)w.localStorage.setItem('quest360-maci-workspace-v1',JSON.stringify(local));
 [...w.document.querySelectorAll('script:not([src])')].forEach(s=>w.eval(s.textContent));modules.forEach(m=>w.eval(fs.readFileSync(path.join(root,'integrations',m+'.js'),'utf8')));
 await pause(500);await w.QuestMaci.load();await w.QuestPersona.render();await pause(160);return{dom,w,d:w.document,errors,downloads};
}
function change(w,n,value){n.value=value;n.dispatchEvent(new w.Event('change',{bubbles:true}));}
function submit(w,f){f.dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));}
const evidence={id:'e-qa',status:'Pending Review',title:'QA customer excerpt',project:'digital-customer-journey',topic:'workflow',kbq:'Ordering friction',method:'Qualitative',segment:'Physicians',geography:'United States',period:'2026-08',sample:'8 interviews',summary:'A source-linked test finding',source:'https://example.org/controlled-study',locator:'Transcript 2, passage 4',limitations:'Purposive sample',stance:'Supports'};
(async()=>{
 for(const team of ['executive','strategy','maci','operations'])for(const role of ['Hub Owner','Contributor','Viewer']){
  const a=await app(team,role),{w,d}=a;
  assert.equal(a.errors.length,0,a.errors.join('\n'));assert(!d.querySelector('#appScreen').classList.contains('hidden'));
  // The 20261012 release deliberately changes Executive's opening route from home to MY HUB.
  assert.equal(d.querySelector('.view.active').dataset.view,'team-dashboard');assert.match(d.querySelector('#qWorkspaceContext').textContent,/Welcome, Quest team/);assert.match(d.querySelector('#qWorkspaceFocus').textContent,new RegExp(role));
  const nav=[...d.querySelectorAll('.nav-item')].filter(n=>n.dataset.teamHidden!=='true').map(n=>n.dataset.view);
  for(const route of ['team-dashboard','copilot','decisions','cx','reports','pmr','library','projects'])assert(nav.includes(route),team+' missing '+route);
  for(const route of nav)assert(w.QuestWorkspaces.teams[team].routes.includes(route),team+' exposes '+route);
  assert.equal(d.querySelector('.nav-item[data-view="team-dashboard"] b').textContent,'MY HUB');
  if(team==='maci'){
   assert.equal(d.querySelector('#pageTitle').textContent,'MY HUB');assert.equal(d.querySelectorAll('[data-qm-hub]').length,1);assert.equal(d.querySelectorAll('[data-qm-tab]').length,5);assert.equal(d.querySelectorAll('.qm-module-panel').length,4);
   assert.match(d.querySelector('#qTeamAssistant').textContent,/Quest Research & Customer Insights Partner/);assert.equal(d.querySelectorAll('#qTeamChatProject option').length,7);assert(!d.querySelector('#qmIncludeDemo').checked);assert.equal(d.querySelector('[data-qm-action="new-request"]').disabled,role==='Viewer');
   await w.QuestMaci.answer('What have Health Systems told us about interoperability?');assert.equal(d.querySelectorAll('.qm-answer-section').length,9);assert.match(d.querySelector('#qTeamAnswer').textContent,/does not contain approved Quest/);assert.match(d.querySelector('#qTeamAnswer').textContent,/Hospital interoperability/);assert(!d.querySelector('#qTeamAnswer').textContent.includes('Illustrative synthesis requested'));
   await w.QuestMaci.answer('sailing yacht engine');assert.match(d.querySelector('#qTeamAnswer').textContent,/No matching topic/);
   w.QuestWorkspaces.go('pmr');await pause(160);assert(d.querySelector('.view[data-view="pmr"] .qm-module-panel'));assert(d.querySelector('[data-pmr-final]'));
   for(const type of w.QuestMaci.getModel().context.report_types)w.QuestMaci.report(type,'digital-customer-journey');assert.equal(a.downloads.length,18);
  }else{
   assert(d.querySelector('[data-qp-root="team-dashboard"]'));
   assert.equal(d.querySelectorAll('[data-qp-tab]').length,5);
   assert.match(d.querySelector('#qTeamAssistant').textContent,new RegExp(team==='operations'?'Product & Operations':team==='strategy'?'Strategy & Market':'Executive Intelligence'));
   await w.QuestPersona.answer('interoperability');assert.match(d.querySelector('#qTeamAnswer').textContent,/Traceability/);assert.match(d.querySelector('#qTeamAnswer').textContent,/No approved Quest customer finding/);
   if(team==='operations'){assert(!nav.includes('news'));assert.equal(w.QuestWorkspaces.includesProject('consumer-testing'),false);}
  }
  assert.equal(w.QuestPersona.can('draft'),role!=='Viewer');assert.equal(w.QuestPersona.can('review'),role==='Hub Owner');
  console.log('PASS workspace',team,role);a.dom.window.close();
 }
 for(const role of ['Hub Owner','Contributor','Viewer']){
  const a=await app('maci',role,{requests:[],evidence:[evidence]}),{w,d}=a;
  const approve=d.querySelector('[data-qm-action="approve-evidence"]');assert.equal(!!approve,role==='Hub Owner');
  if(approve){approve.click();assert.equal(JSON.parse(w.localStorage.getItem('quest360-maci-workspace-v1')).evidence[0].status,'Approved');await w.QuestMaci.answer('workflow');assert.match(d.querySelector('#qTeamAnswer').textContent,/QA customer excerpt/);}
  if(role!=='Viewer'){
   d.querySelector('[data-qm-action="new-request"]').click();const f=d.querySelector('[data-qm-form="request"]');assert(f);
   for(const[k,v]of Object.entries({question:'Health system interoperability workflow',decision:'Choose the next research question',customer:'Health systems',geography:'US'}))f.elements[k].value=v;
   submit(w,f);assert.equal(JSON.parse(w.localStorage.getItem('quest360-maci-workspace-v1')).requests.length,1);assert.equal(!!d.querySelector('[data-qm-request-status]'),role==='Hub Owner');
   if(role==='Hub Owner'){change(w,d.querySelector('[data-qm-request-status]'),'Existing Evidence Found');assert.equal(JSON.parse(w.localStorage.getItem('quest360-maci-workspace-v1')).requests[0].status,'Existing Evidence Found');}
   d.querySelector('[data-qm-action="new-evidence"]').click();const ef=d.querySelector('[data-qm-form="evidence"]');assert(ef);for(const[k,v]of Object.entries(evidence))if(ef.elements[k])ef.elements[k].value=v;
   ef.elements.title.value='<img src=x onerror=alert(1)>';submit(w,ef);const records=JSON.parse(w.localStorage.getItem('quest360-maci-workspace-v1')).evidence;assert.equal(records.length,2);assert.equal(records[1].status,'Pending Review');assert(!d.querySelector('.qm-local img'));
  }else{const b=d.querySelector('[data-qm-action="new-request"]');b.disabled=false;b.click();assert(!d.querySelector('[data-qm-form="request"]'));}
  assert.equal(a.errors.length,0,a.errors.join('\n'));console.log('PASS request / evidence permissions',role);a.dom.window.close();
 }
 const a=await app('maci','Hub Owner');const snapshot=a.d.querySelector('.view[data-view="team-dashboard"]').innerHTML;
 a.d.querySelector('#qChangeWorkspace').click();a.d.querySelector('#teamScreen [data-team="executive"]').click();a.d.querySelector('#qDisplayName').value='Ada';a.d.querySelector('#qTeamContinue').click();a.d.querySelector('#roleScreen [data-role="Hub Owner"]').click();a.d.querySelector('#enterHub').click();await pause(500);
 assert.equal(a.d.querySelector('.view.active').dataset.view,'team-dashboard');assert(a.d.querySelector('[data-qp-root="team-dashboard"]'));assert.match(a.d.querySelector('#qWorkspaceContext').textContent,/Ada/);
 a.d.querySelector('#qChangeWorkspace').click();a.d.querySelector('#teamScreen [data-team="operations"]').click();a.d.querySelector('#qTeamContinue').click();a.d.querySelector('#enterHub').click();await pause(500);
 assert.equal(a.d.querySelectorAll('.qm-module-panel').length,0);assert.equal(a.d.querySelector('#qmExecutiveCenter'),null);assert.equal(a.errors.length,0,a.errors.join('\n'));console.log('PASS team switching and personalized greeting');
 if(process.env.QUEST_MACI_SNAPSHOT_PATH)fs.writeFileSync(process.env.QUEST_MACI_SNAPSHOT_PATH,'<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{background:#f6f8f1;margin:30px;font:14px Arial}</style><style>'+fs.readFileSync(path.join(root,'integrations/maci-research-center.css'),'utf8')+'</style></head><body>'+snapshot+'</body></html>');
 a.dom.window.close();console.log('All MACI and persona integration checks passed.');
})().catch(e=>{console.error(e.stack);process.exit(1);});
